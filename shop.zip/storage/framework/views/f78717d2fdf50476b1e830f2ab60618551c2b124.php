

<?php $__env->startSection('content'); ?>
<div class="container mt-3 mb-3">
    <h2>New Product</h2>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('products.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        Name:<br>
        <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" /><br>
        
        Price ($):<br>
        <input type="text" name="price" value="<?php echo e(old('price')); ?>" class="form-control" /><br>

        Category:<br>
        <select name="category_id" value="" class="form-control" >
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>"<?php if($category->id == old('category_id')): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </select><br>

        Photo:<br>
        <input type="file" name="photo"  /><br><br>
        <input type="submit" class="btn btn-primary" value="Save" /><br><br>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/products/create.blade.php ENDPATH**/ ?>