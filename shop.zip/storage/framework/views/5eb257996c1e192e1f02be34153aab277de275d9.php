

<?php $__env->startSection('content'); ?>
<div class="row mt-3 mb-3">
    <div class="col-md">
        <div class="card card-body">
            <h2>Categories</h2>
            <?php if(session('successMsg')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('successMsg')); ?>

            </div>
            <?php endif; ?>
        </div>
        <div class="card card-body">
            <table class="table">
                <a class="btn btn-primary" href="<?php echo e(route('categories.create')); ?>">Create Category</a>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->id); ?></td>
                        <td><?php echo e($category->name); ?></td>
                        <td>
                            <a class="btn btn-raised btn-success btn-sm" href="<?php echo e(route('categories.edit', $category->id )); ?>">Edit</i></a>
                            
                                <form method="POST" id="delete-form-<?php echo e($category->id); ?>" action="<?php echo e(route('categories.destroy', $category->id)); ?>" 
                                    style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('delete')); ?>

                                </form>
                                <button onclick="if (confirm('Are you sure delete this data?')) {
                                    event.preventDefault();
                                    document.getElementById('delete-form-<?php echo e($category->id); ?>').submit();
                                }else{
                                    event.preventDefault();
                                }" class="btn btn-raised btn-danger btn-sm" href="<?php echo e(route('categories.edit', $category->id)); ?>">Delete
                                </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/categories/index.blade.php ENDPATH**/ ?>