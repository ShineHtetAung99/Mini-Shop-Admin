

<?php $__env->startSection('content'); ?>

<h2>Category Edit</h2>
<form action="<?php echo e(route('categories.update', $category->id)); ?>" method="POST">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
    Name:<br>
    <input type="text" name="name" value="<?php echo e($category->name); ?>" class="form-control" /><br>
    <input type="submit" class="btn btn-primary" value="Update" /><br><br>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/categories/edit.blade.php ENDPATH**/ ?>