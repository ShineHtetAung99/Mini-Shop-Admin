

<?php $__env->startSection('content'); ?>

<h1>Contact</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/contact.blade.php ENDPATH**/ ?>