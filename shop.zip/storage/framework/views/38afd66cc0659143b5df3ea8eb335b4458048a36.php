<footer class="py-5 bg-dark">
    <div class="container"><p class="m-0 text-center text-white">Copyright &copy; Your Website 2022</p></div>
</footer><?php /**PATH C:\xampp\htdocs\shop\resources\views/footer.blade.php ENDPATH**/ ?>