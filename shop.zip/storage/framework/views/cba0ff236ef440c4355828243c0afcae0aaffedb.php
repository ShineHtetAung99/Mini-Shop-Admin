

<?php $__env->startSection('content'); ?>
<div class="container mt-3 mb-3">
    <h2>Edit Product</h2>
    <form action="<?php echo e(route('products.update', $product)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        Name:<br>
        <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control" /><br>
        
        Price ($):<br>
        <input type="text" name="price" value="<?php echo e($product->price); ?>" class="form-control" /><br>

        Category:<br>
        <select name="category_id" value="" class="form-control" >
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php if($category->id == $product->category_id): ?> selected <?php endif; ?>><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </select><br>

        Photo:<br>
        <input type="file" name="photo" /><br><br>
        <input type="submit" class="btn btn-primary" value="Update" /><br><br>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/products/edit.blade.php ENDPATH**/ ?>